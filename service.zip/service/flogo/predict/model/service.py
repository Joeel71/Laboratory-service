import torch
from flask import Flask, request
from architecture import architecture
from implementations.pytorch.toolbox.device import PytorchDevice as Device
from implementations.pytorch.toolbox.loader import PytorchModelLoader as ModelLoader

app = Flask(__name__)

model = ModelLoader().load(path="/app/model/model.weights", architecture=architecture, device=Device(-1))


@app.route('/predict', methods=['POST'])
def predict():
    return model.predict(torch.tensor(request.json.get('input')))


if __name__ == '__main__':
    app.run(host='0.0.0.0', port=80)