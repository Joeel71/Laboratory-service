from framework.architecture.layer import Layer


class RegularizationLayer(Layer):
    pass
