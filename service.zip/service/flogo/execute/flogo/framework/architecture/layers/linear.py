from framework.architecture.layer import Layer


class LinearLayer(Layer):
    pass
