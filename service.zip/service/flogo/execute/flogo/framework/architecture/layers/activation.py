from framework.architecture.layer import Layer


class ActivationLayer(Layer):
    pass
