from framework.architecture.layer import Layer


class ConvolutionalLayer(Layer):
    pass
