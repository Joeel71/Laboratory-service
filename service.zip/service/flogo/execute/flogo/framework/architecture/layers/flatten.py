from framework.architecture.layer import Layer


class FlattenLayer(Layer):
    pass


