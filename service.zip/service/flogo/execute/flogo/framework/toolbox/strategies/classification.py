from abc import ABC

from framework.toolbox.strategy import Strategy


class ClassificationStrategy(Strategy, ABC):
    pass
